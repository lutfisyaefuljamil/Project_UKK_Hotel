<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container-fluid">
      <a class="navbar-brand" href="#">LiaPiw Hotel</a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="/">Home</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('kamar')); ?>">Kamar</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('fasilitas')); ?>">Fasilitas</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="/login">Logout</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
<ul class="nav nav-pills" id="pills-tab" role="tablist">
    <div class="card card-brown nav-item rounded-10 mt-3 me-3" style="width: 16rem;">
        <div class="card-body text-brown">
            <h1 class="card-title">50</h1>
            <p class="card-text">Jumlah Kamar</p>
        </div>
    </div>
    <div class="card card-brown nav-item rounded-10 mt-3 me-3" style="width: 16rem;">
        <div class="card-body text-brown">
            <h1 class="card-title">50</h1>
            <p class="card-text">Kamar Tersedia</p>
        </div>
    </div>
    <div class="card card-brown nav-item rounded-10 mt-3 me-3" style="width: 16rem;">
        <div class="card-body text-brown">
            <h1 class="card-title">50</h1>
            <p class="card-text">Jumlah Fasilitas</p>
        </div>
    </div>
    <div class="card card-brown nav-item rounded-10 mt-3 me-3" style="width: 16rem;">
        <div class="card-body text-brown">
            <h1 class="card-title">50</h1>
            <p class="card-text">Total Tamu yang Pernah Berkunjung</p>
        </div>
    </div>
    <div class="card card-brown nav-item rounded-10 mt-3 me-3" style="width: 16rem;">
        <div class="card-body text-brown">
            <h1 class="card-title">50</h1>
            <p class="card-text">Jumlah Tamu yang Sedang Berkunjung</p>
        </div>
    </div>
</ul>
<?php /**PATH C:\Project_UKK_Hotel\resources\views/admin.blade.php ENDPATH**/ ?>